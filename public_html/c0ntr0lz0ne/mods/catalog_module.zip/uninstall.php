<?
  $sql_delete = array('0'=>"DROP TABLE `".TBL_PREF."catalog_categories`",
                      '1'=>"DROP TABLE `".TBL_PREF."catalog_manufacturers`",
                      '2'=>"DROP TABLE `".TBL_PREF."catalog_p2c`",
                      '3'=>"DROP TABLE `".TBL_PREF."catalog_products`" );

  $sql_delconfig = "DELETE FROM ".TBL_PREF."settings WHERE kind='catalog'";

  foreach($sql_delete as $k=>$v) mysql_query($v);
  mysql_query($sql_delconfig);
?>